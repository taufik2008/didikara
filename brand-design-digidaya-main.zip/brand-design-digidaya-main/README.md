# Digidaya — Red Brand Kit

Identitas pilihan: **Daya Progresif / opsi 1 merah**.

## Mulai dari sini

1. Buka `Digidaya-Daya-Progresif-Brand-Guide.pdf` untuk panduan visual.
2. Baca `BRAND-GUIDE.md` atau berikan file ini kepada AI sebagai instruksi desain.
3. Pakai `logos/digidaya-horizontal-primary.svg` pada latar putih/cream.
4. Impor `tokens/brand-tokens.css` atau baca `tokens/brand-tokens.json` untuk implementasi.

## Isi paket

- `logos/`: 8 SVG outlined dan 8 PNG transparan. Susunan horizontal/stacked; primary, ink, red, white.
- `icons/`: 3 simbol SVG dan PNG transparan, app icon SVG, PNG 180/192/512/1024, favicon SVG/ICO/PNG 16/32/48/64, apple-touch icon, web manifest.
- `fonts/`: Manrope dan Inter variable TTF, masing-masing beserta lisensi OFL.
- `tokens/`: token warna, tipografi, spacing, radius, serta CSS font-face dan custom properties.
- `BRAND-GUIDE.md`: aturan lengkap untuk manusia dan AI.
- `ASSET-MANIFEST.json`: inventaris file, ukuran, dan SHA-256 untuk memeriksa kelengkapan paket.

## Format dan penggunaan

SVG logo berisi path, bukan teks yang bergantung pada font. PNG logo memiliki latar transparan; versi putih perlu dilihat di atas latar gelap. Ikon aplikasi memiliki latar crimson solid dan simbol putih di area aman.

Semua varian menggunakan geometri simbol merah yang dipilih. Stacked dan ukuran ikon adalah susunan/ekspor dari aset yang sama, bukan konsep logo baru.

Palet inti: `#B51F32`, `#2B1720`, `#FFC4BD`, `#FCF3F2`, `#FFFFFF`.
Heading: Manrope. Body: Inter.

Font berasal dari distribusi Google Fonts:
- https://github.com/google/fonts/tree/main/ofl/manrope
- https://github.com/google/fonts/tree/main/ofl/inter

PDF adalah panduan visual dan contoh penerapan, bukan berkas brosur atau kalender siap cetak. Gunakan profil ICC serta proof percetakan untuk produksi fisik.
