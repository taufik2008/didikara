# Digidaya — Daya Progresif

Version: 1.0.0
Status: arah visual pilihan pengguna, berdasarkan opsi 1 merah pada dokumen sebelumnya.
Bahasa utama: Indonesia. Nama merek: **Digidaya**. Wordmark resmi dalam aset: **DIGIDAYA**.

## Instruksi untuk AI

1. Gunakan arah **Daya Progresif** dan aset dalam paket ini sebagai sumber utama.
2. Jangan menggambar ulang, menghasilkan ulang, atau mengganti simbol dengan huruf, emoji, ikon pustaka, atau CSS. Gunakan SVG yang disediakan.
3. Pertahankan geometri, proporsi, warna, dan wordmark pada aset. Semua huruf pada logo SVG sudah diubah menjadi path.
4. Terapkan token dari `tokens/brand-tokens.json` atau `tokens/brand-tokens.css`. Palet inti dan font adalah keputusan brand; token interaksi adalah turunan implementasi.
5. Jangan memakai identitas hijau, ungu, petrol, atau alternatif logo dari eksplorasi sebelumnya.
6. Jangan menambahkan nama perusahaan induk, endorsement perusahaan lain, domain, alamat, atau kontak yang tidak diberikan.
7. Gunakan informasi produk di bawah persis sesuai scope. Jangan mengarang fitur, klaim performa, pelanggan, sertifikasi, atau hasil AI.
8. Preview semua logo putih di atas latar gelap. PNG putih transparan memang tidak terlihat di latar putih.
9. Pada penyerahan desain, periksa keterbacaan, kontras, konsistensi aset, tampilan responsif, dan tidak ada elemen terpotong.

## Posisi dan karakter

Digidaya adalah payung layanan IT dan produk digital. Karakter: **berani, terarah, progresif**, dengan struktur yang jelas dan komunikasi yang mudah dipahami.

Tagline dalam arah visual: **Teknologi untuk langkah besar.**
Tagline boleh tidak dipakai pada header aplikasi atau ruang kecil. Tagline bukan bagian wajib geometri logo.

### Layanan

- IT Infrastructure & Support.
- Data Visualization, termasuk Power BI.
- Implementasi ERP Odoo.
- Custom Software, AI & Automation.

### Produk

| Nama | Deskripsi |
|---|---|
| SEKALA | Budgeting untuk perusahaan tambang batu bara. |
| DIGITARA | Platform e-learning. |
| Schemax | SLD Analyzer. |
| Swakara | Perencanaan produk dan penyusunan PRD sebelum coding. |
| ATR | Applicant Tracking System berbantuan AI. |

Gunakan format `SEKALA by Digidaya` atau nama produk lain dengan pola yang sama jika perlu menunjukkan keluarga produk. Odoo dan Power BI adalah teknologi layanan, bukan produk milik Digidaya. Paket ini berisi identitas Digidaya; tidak berisi logo mandiri untuk setiap produk.

## Logo

Simbol pilihan adalah monogram d abstrak, berupa satu bidang melengkung di kiri dan batang tegak di kanan. Geometri berasal dari logo merah yang dipilih, bukan alternatif premium hijau.

### Pilih file yang tepat

| Kebutuhan | File |
|---|---|
| Logo utama pada latar putih/cream | `logos/digidaya-horizontal-primary.svg` |
| Logo satu warna gelap | `logos/digidaya-horizontal-ink.svg` |
| Logo seluruhnya crimson | `logos/digidaya-horizontal-red.svg` |
| Logo putih pada latar gelap/crimson | `logos/digidaya-horizontal-white.svg` |
| Ruang sempit atau layout vertikal | `logos/digidaya-stacked-*.svg` |
| Simbol tanpa wordmark | `icons/digidaya-symbol-red.svg` |
| Simbol gelap/putih | `icons/digidaya-symbol-ink.svg` / `icons/digidaya-symbol-white.svg` |
| Ikon aplikasi | `icons/digidaya-app-icon.svg` atau PNG ukuran yang sesuai |
| Favicon | `icons/favicon.svg` dan `icons/favicon.ico` |

PNG transparan tersedia untuk semua logo dan simbol. Utamakan SVG untuk web, presentasi, dan produksi cetak karena tetap tajam saat diperbesar. Jangan memakai PNG kecil untuk dicetak besar.

### Aturan penggunaan

- Logo utama: simbol crimson `#B51F32` + wordmark ink `#2B1720`.
- Pertahankan rasio lebar/tinggi. Gunakan `height: auto` atau `object-fit: contain`.
- Ruang bebas minimum: `x = 1/4 tinggi bentuk simbol yang terlihat`, di sekeliling batas artwork. Pastikan padding container juga memenuhi ruang ini.
- Minimum awal untuk lockup horizontal: lebar 140 px digital / 32 mm cetak. Untuk ikon simbol: 24 px / 6 mm. Di bawah ukuran tersebut gunakan favicon yang disediakan dan periksa visualnya pada ukuran aktual.
- Favicon 16 px adalah ekspor geometri asli untuk kebutuhan browser; bukan versi optik yang digambar ulang.
- Jangan memutar, meregangkan, memiringkan, menambahkan outline/shadow/gradien, mengubah jarak simbol-wordmark, atau mengubah susunan huruf logo.
- Jangan memakai versi putih di latar terang, atau versi primary di latar yang terlalu dekat warnanya.
- Batasi pola logo sebagai dekorasi; jangan menempatkannya di belakang teks utama.
- SVG lockup telah di-outline. Font tetap diperlukan untuk seluruh teks antarmuka, bukan untuk merender aset logo.

## Warna

| Token | HEX | RGB | Peran |
|---|---|---|---|
| primary | `#B51F32` | 181, 31, 50 | Logo, CTA utama, link dan elemen aktif |
| ink | `#2B1720` | 43, 23, 32 | Teks utama, navigasi, versi logo gelap |
| accent | `#FFC4BD` | 255, 196, 189 | Sorotan dan bidang ilustrasi |
| surface | `#FCF3F2` | 252, 243, 242 | Canvas/latar lembut |
| white | `#FFFFFF` | 255, 255, 255 | Card, panel, logo reverse |

Proporsi awal: sekitar 70% netral (white/surface), 20% primary/ink, maksimum 10% accent. Ini pedoman komposisi, bukan kewajiban pembagian piksel.

### Token UI turunan

- Primary hover: `#96192A`; pressed: `#7B1422`.
- Teks sekunder: `#6F5960`; border dekoratif: `#E7D9DB`.
- Success: `#166534`; warning: `#854D0E`; error: `#B91C1C`; info: `#1D4ED8`.
- Token status digunakan bersama teks/ikon. Merah brand pada CTA bukan berarti error. Error perlu label jelas seperti “Gagal menyimpan” dan ikon status.
- Border `#E7D9DB` bukan satu-satunya penanda interaksi; gunakan label, focus ring, dan batas yang lebih kuat jika komponen membutuhkannya.
- Teks tombol utama putih pada crimson. Teks pada accent menggunakan ink, bukan putih.
- Putih pada primary memiliki rasio kontras sekitar **6.55:1**. Tetap uji pasangan warna dan state yang benar-benar digunakan pada desain baru.
- Jangan menganggap palet ini sebagai dark theme lengkap. Untuk dark mode, definisikan pasangan surface/text/state dan uji kontras secara terpisah.

## Tipografi

- Heading: **Manrope**, bobot 600–700. Wordmark yang dipilih memakai Manrope 700 dalam bentuk path.
- Body/UI: **Inter**, bobot 400 untuk isi, 500–600 untuk penekanan dan kontrol.
- Fallback: `Arial, sans-serif`.
- Font variable disertakan di `fonts/`; lisensi OFL disertakan per keluarga.
- Jangan mengganti font heading dengan serif atau font display dekoratif.

| Peran | Ukuran / line height |
|---|---|
| H1 desktop | 40 / 48 px |
| H2 | 28 / 36 px |
| Body | 16 / 24 px |
| Label | 14 / 20 px |
| Judul cetak | 28–36 pt |
| Body cetak | 10–11 pt |
| Caption cetak | 8–9 pt |

Pada mobile, body tetap minimal 16 px; heading boleh menyesuaikan panjang teks. Untuk tabel keuangan gunakan angka tabular dan perataan kanan. Jangan memberi tracking wordmark pada semua judul; tracking khusus sudah tertanam dalam aset logo.

## Layout dan komponen

- Spacing: 4, 8, 12, 16, 24, 32, 48, 64 px.
- Radius awal kontrol/card: 6 px. Shell perangkat pada mockup bukan radius komponen produk.
- Desktop: grid 12 kolom; mobile: 4 kolom. Gunakan gutter yang konsisten dan ruang kosong yang cukup.
- Target sentuh minimum: 44 × 44 px.
- Primary button crimson/white; secondary button ink atau outline yang terbaca; satu aksi utama per bagian.
- Focus keyboard: ring 2 px dengan offset 2 px, memakai warna yang kontras terhadap latarnya.
- Ikon UI: outline 1.5–2 px dengan ukuran konsisten. Ikon UI umum bukan turunan/pengganti logo brand.
- Form: label tetap terlihat, bantuan dan error diletakkan dekat input, state tidak dibedakan hanya dengan warna.
- Data visualization: warna, label langsung, bentuk, atau pola digunakan bersama. Jangan menjadikan merah satu-satunya penanda negatif karena merah juga warna brand.
- Data pada PDF adalah ilustrasi; jangan memakainya sebagai data produksi atau klaim hasil nyata.

## Bahasa dan gambar

Gunakan bahasa aktif, pendek, dan berorientasi tindakan: “Tinjau hasil ekstraksi”, “Susun kebutuhan produk”, “Review anggaran”. Hindari janji bahwa AI selalu akurat atau pasti menghasilkan hasil tertentu.

Foto mengutamakan kerja nyata, manusia, perangkat, dan konteks industri. Ilustrasi berfokus pada sistem, alur, dan struktur; jangan memakai robot atau sirkuit sebagai dekorasi default.

## Cetak

- Brosur A4: 210 × 297 mm, bleed 3 mm, safe area 10 mm.
- Kalender meja contoh: 210 × 148 mm, area binding 15 mm.
- Gunakan logo SVG/PDF vektor. Foto minimal 300 ppi pada ukuran cetak aktual.
- HEX/RGB adalah master digital. Konversi ke CMYK menggunakan profil ICC percetakan dan proof fisik. Tidak ada angka CMYK universal yang dijamin identik.
- Kalender pada PDF merupakan contoh komposisi Januari 2027, belum memuat hari libur.

## Contoh implementasi

```html
<link rel="stylesheet" href="/brand/tokens/brand-tokens.css">
<img src="/brand/logos/digidaya-horizontal-primary.svg"
     alt="Digidaya" style="width:180px;height:auto">
<link rel="icon" href="/brand/icons/favicon.svg" type="image/svg+xml">
<link rel="alternate icon" href="/brand/icons/favicon.ico">
<link rel="apple-touch-icon" href="/brand/icons/apple-touch-icon.png">
<link rel="manifest" href="/brand/icons/site.webmanifest">
```

`/brand/` adalah contoh lokasi deployment; sesuaikan dengan aplikasi. Jangan menggunakan path lokal komputer pembuat. Pertahankan posisi relatif folder font terhadap CSS atau perbarui URL-nya saat memindahkan file.

```css
body { font-family: var(--font-body); color: var(--color-ink); background: var(--color-surface); }
h1, h2, h3 { font-family: var(--font-heading); }
.button-primary { background: var(--color-primary); color: var(--color-white); border-radius: var(--radius-control); }
.button-primary:hover { background: var(--color-primary-hover); }
.button-primary:focus-visible { outline: 2px solid var(--color-ink); outline-offset: 2px; }
```

## Prompt ringkas untuk AI

> Baca BRAND-GUIDE.md dan tokens/brand-tokens.json dalam paket Digidaya. Gunakan arah merah Daya Progresif, font Manrope dan Inter, serta SVG logo yang disediakan. Jangan menggambar ulang logo atau menambahkan perusahaan induk. Terapkan aturan spacing, komponen, aksesibilitas, serta nama dan scope produk sesuai panduan. Buat desain sesuai kebutuhan tugas, lalu periksa tampilan desktop/mobile dan keterbacaan sebelum menyerahkan hasil.
